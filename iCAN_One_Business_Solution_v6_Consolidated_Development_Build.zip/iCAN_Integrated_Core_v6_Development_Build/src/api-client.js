/* iCAN API bridge for development. Token storage uses sessionStorage only for this local prototype.
   For production, replace browser-stored bearer tokens with a reviewed secure session strategy. */
(() => {
  const DEFAULT_API_BASE = 'http://localhost:4000';
  const apiBase = () => (window.ICAN_API_BASE || DEFAULT_API_BASE).replace(/\/$/, '');
  const state = { token: sessionStorage.getItem('ican_dev_access_token') || '', workspaceId: sessionStorage.getItem('ican_dev_workspace_id') || '', user: null, workspace: null };
  const $ = (s) => document.querySelector(s);
  const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (state.token) headers.Authorization = `Bearer ${state.token}`;
    let response;
    try { response = await fetch(apiBase() + path, { ...options, headers }); }
    catch { throw new Error(`Cannot reach ${apiBase()}. Start the iCAN API and check its address.`); }
    const body = response.status === 204 ? null : await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body?.error || `Request failed (${response.status})`);
    return body;
  }
  function toast(message) {
    const el = $('#toast'); if (!el) return;
    el.textContent = message; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2800);
  }
  function addStyles() {
    const style = document.createElement('style');
    style.textContent = `#icanApiButton{white-space:nowrap}#icanApiStatus{font-size:10px;color:#667085;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.api-dialog{padding:0;max-width:460px}.api-dialog .api-content{padding:18px 22px}.api-dialog input{width:100%;padding:11px;border:1px solid #d0d5dd;border-radius:8px}.api-dialog .api-field{margin:12px 0}.api-dialog label{display:block;font-size:11px;font-weight:700;margin-bottom:6px}.api-dialog .api-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}.api-dialog .api-warning{font-size:11px;color:#8a4b08;background:#fff8e8;border:1px solid #f5d38b;padding:10px;border-radius:8px;line-height:1.5}`;
    document.head.append(style);
  }
  function addAuthUI() {
    const header = $('header'); if (!header || $('#icanApiButton')) return;
    const button = document.createElement('button'); button.id = 'icanApiButton'; button.className = 'btn'; button.textContent = state.token ? 'API connected' : 'Connect API';
    const status = document.createElement('span'); status.id = 'icanApiStatus'; status.textContent = state.token ? 'Checking session…' : 'Local demo mode';
    header.insertBefore(status, header.querySelector('.avatar'));
    header.insertBefore(button, status);
    button.addEventListener('click', () => openAuthDialog());
    const dialog = document.createElement('dialog'); dialog.id = 'icanAuthDialog'; dialog.className = 'api-dialog';
    dialog.innerHTML = `<div class="modalhead"><h2>Connect to your iCAN API</h2><button type="button" id="icanAuthClose" class="btn">Close</button></div><div class="api-content"><div class="api-warning">Development mode only. Use test data. This starter stores a short-lived bearer token in this browser tab's session storage; do not use it as a production session design.</div><div class="api-field"><label for="icanApiBase">API address</label><input id="icanApiBase" value="${escapeHtml(apiBase())}" autocomplete="url"></div><div class="api-field"><label for="icanAuthMode">Action</label><select id="icanAuthMode"><option value="login">Sign in</option><option value="register">Create account + workspace</option></select></div><div class="api-field" id="icanNameField" hidden><label for="icanAuthName">Your name</label><input id="icanAuthName" autocomplete="name"></div><div class="api-field" id="icanWorkspaceField" hidden><label for="icanWorkspaceName">Business / workspace name</label><input id="icanWorkspaceName" autocomplete="organization"></div><div class="api-field"><label for="icanAuthEmail">Email</label><input id="icanAuthEmail" type="email" autocomplete="email" required></div><div class="api-field"><label for="icanAuthPassword">Password</label><input id="icanAuthPassword" type="password" autocomplete="current-password" required></div><div class="api-actions"><button id="icanAuthSubmit" class="btn primary" type="button">Sign in</button><button id="icanAuthLogout" class="btn" type="button" ${state.token ? '' : 'hidden'}>Disconnect / sign out</button></div><p id="icanAuthMessage" role="status" class="muted"></p></div>`;
    document.body.append(dialog);
    $('#icanAuthClose').onclick = () => dialog.close();
    $('#icanAuthMode').onchange = updateMode;
    $('#icanAuthSubmit').onclick = submitAuth;
    $('#icanAuthLogout').onclick = logout;
    $('#icanApiBase').oninput = () => { window.ICAN_API_BASE = $('#icanApiBase').value.trim().replace(/\/$/, ''); };
    updateMode();
  }
  function updateMode() {
    const register = $('#icanAuthMode').value === 'register';
    $('#icanNameField').hidden = !register; $('#icanWorkspaceField').hidden = !register;
    $('#icanAuthSubmit').textContent = register ? 'Create account' : 'Sign in';
    $('#icanAuthPassword').autocomplete = register ? 'new-password' : 'current-password';
  }
  function openAuthDialog() { $('#icanAuthMessage').textContent = ''; $('#icanAuthDialog').showModal(); }
  function updateHeader() {
    const button = $('#icanApiButton'), status = $('#icanApiStatus');
    if (!button || !status) return;
    button.textContent = state.token ? 'Connected · Account' : 'Connect API';
    status.textContent = state.user ? `${state.user.name} · ${state.workspace?.name || 'Workspace'}` : (state.token ? 'API token active' : 'Local demo mode');
    const profile = document.querySelector('.profile');
    if (profile && state.user) profile.innerHTML = `🧑🏻‍💼 <span><b>${escapeHtml(state.user.name)}</b><small>${escapeHtml(state.workspace?.role || 'Workspace member')}</small></span>`;
    const footerStatus = document.querySelector('footer span'); if (footerStatus) footerStatus.textContent = state.token ? 'API connected · Tasks stored in PostgreSQL' : 'Local demo mode · Tasks saved in this browser';
  }
  function toLocalTask(task) {
    return { id: task.id, title: task.title, due: task.due_date || '', priority: ({low:'Low',normal:'Normal',high:'High',urgent:'Urgent'})[task.priority] || 'Normal', done: Boolean(task.completed_at), description: task.description || '' };
  }
  async function loadTasks() {
    if (!state.token || !state.workspaceId) return;
    const data = await request(`/api/tasks?workspaceId=${encodeURIComponent(state.workspaceId)}`);
    window.icanSetRemoteTasks?.(data.tasks || []);
  }
  async function submitAuth() {
    const message = $('#icanAuthMessage'); const base = $('#icanApiBase').value.trim().replace(/\/$/, '');
    if (!base) { message.textContent = 'Enter the API address.'; return; }
    window.ICAN_API_BASE = base;
    const mode = $('#icanAuthMode').value;
    const email = $('#icanAuthEmail').value.trim(), password = $('#icanAuthPassword').value;
    const payload = { email, password };
    if (mode === 'register') { payload.name = $('#icanAuthName').value.trim(); payload.workspaceName = $('#icanWorkspaceName').value.trim(); if (password.length < 12) { message.textContent = 'For registration, use a unique password with at least 12 characters.'; return; } }
    if (!email || !password || (mode === 'register' && (!payload.name || !payload.workspaceName))) { message.textContent = 'Complete all required fields.'; return; }
    const submit = $('#icanAuthSubmit'); submit.disabled = true; message.textContent = 'Connecting…';
    try {
      const result = await request(`/api/auth/${mode === 'register' ? 'register' : 'login'}`, { method: 'POST', body: JSON.stringify(payload), headers: {} });
      state.token = result.accessToken; state.user = result.user;
      if (mode === 'register') state.workspace = { ...result.workspace, role: 'owner' };
      else {
        const me = await request('/api/auth/me'); state.user = me.user; state.workspace = me.workspaces?.[0] || null;
      }
      state.workspaceId = state.workspace?.id || '';
      if (!state.workspaceId) throw new Error('No workspace was returned for this account.');
      sessionStorage.setItem('ican_dev_access_token', state.token); sessionStorage.setItem('ican_dev_workspace_id', state.workspaceId);
      $('#icanAuthLogout').hidden = false; $('#icanAuthDialog').close(); updateHeader(); await loadTasks(); toast('Connected to iCAN API. Tasks now use PostgreSQL.');
    } catch (error) { message.textContent = error.message; }
    finally { submit.disabled = false; }
  }
  async function logout() {
    state.token = ''; state.workspaceId = ''; state.user = null; state.workspace = null;
    sessionStorage.removeItem('ican_dev_access_token'); sessionStorage.removeItem('ican_dev_workspace_id');
    updateHeader(); $('#icanAuthDialog').close(); toast('Disconnected. Demo data remains local.');
  }
  async function restoreSession() {
    if (!state.token) { updateHeader(); return; }
    try { const me = await request('/api/auth/me'); state.user = me.user; state.workspace = me.workspaces?.find(w => w.id === state.workspaceId) || me.workspaces?.[0] || null; state.workspaceId = state.workspace?.id || ''; await loadTasks(); }
    catch { state.token = ''; state.workspaceId = ''; sessionStorage.removeItem('ican_dev_access_token'); sessionStorage.removeItem('ican_dev_workspace_id'); }
    updateHeader();
  }
  const api = {
    isConnected: () => Boolean(state.token && state.workspaceId),
    toLocalTask,
    async createSubscriptionCheckout(planId, interval = 'monthly') {
      if (!state.token || !state.workspaceId) throw new Error('Connect API and choose a workspace first.');
      const idempotencyKey = (window.crypto?.randomUUID ? window.crypto.randomUUID() : `sub-${Date.now()}-${Math.random().toString(16).slice(2)}`);
      return request('/api/payments/subscription/checkout', { method: 'POST', body: JSON.stringify({ workspaceId: state.workspaceId, planId, interval, idempotencyKey }) });
    },
    async loadPaymentStatus() {
      if (!state.token || !state.workspaceId) throw new Error('Connect API and choose a workspace first.');
      const result = await request(`/api/payments/status?workspaceId=${encodeURIComponent(state.workspaceId)}`);
      const current = document.querySelector('#icanPlanCurrent'); if (current) current.textContent = result.subscription?.plan_id || 'free';
      const status = document.querySelector('#icanPlanStatus'); if (status) status.textContent = result.subscription?.status || 'free';
      const history = document.querySelector('#icanPaymentHistory');
      if (history) history.innerHTML = (result.transactions || []).map(x => `<div class="activity"><div class="details"><b>${escapeHtml(x.purpose === 'ican_subscription' ? `Subscription · ${x.plan_id || ''}` : 'Merchant order')}</b><small>${escapeHtml(x.status)} · ${escapeHtml(new Date(x.created_at).toLocaleString())}</small></div><strong>${escapeHtml(x.currency)} ${Number(x.amount || 0).toLocaleString()}</strong></div>`).join('') || '<p class="muted">No transactions yet.</p>';
      return result;
    },
    async createMerchantCheckout(data) {
      if (!state.token || !state.workspaceId) throw new Error('Connect API and choose a workspace first.');
      return request('/api/payments/merchant/checkout', { method: 'POST', body: JSON.stringify({ ...data, workspaceId: state.workspaceId }) });
    },
    async createTask(data) {
      const priority = ({Low:'low',Normal:'normal',High:'high',Urgent:'urgent'})[data.priority] || 'normal';
      const result = await request('/api/tasks', { method: 'POST', body: JSON.stringify({ workspaceId: state.workspaceId, title: data.title, dueDate: data.due || null, priority }) });
      return result.task;
    },
    async updateTask(id, patch) { const result = await request(`/api/tasks/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ workspaceId: state.workspaceId, ...patch }) }); return result.task; },
    async deleteTask(id) { await request(`/api/tasks/${encodeURIComponent(id)}?workspaceId=${encodeURIComponent(state.workspaceId)}`, { method: 'DELETE' }); }
  };
  window.icanBackend = api;
  addStyles();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { addAuthUI(); restoreSession(); });
  else { addAuthUI(); restoreSession(); }
})();
